package com.example.usuario.proyectoformulario;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText edit1,edit2,edit3;
    TextView tv3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit1 = (EditText) findViewById(R.id.editText3);
        edit2 = (EditText) findViewById(R.id.editText5);
        edit3 = (EditText) findViewById(R.id.editText6);

        tv3 = (TextView) findViewById(R.id.textView4);
    }

    public void guardar(View v) {
         tv3.setText(edit1.getText().toString() +""+ edit2.getText().toString() + "" + edit3.getText().toString());

    }
}
